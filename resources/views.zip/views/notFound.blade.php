<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('/assets/css/style.css') }}" rel="stylesheet" />
    <title>not found</title>
</head>
<body>
  <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); display: flex;flex-direction: column ;justify-content:center;align-items: center;">
    <h1>NOT FOUND</h1>
    <img class="w-50"  src="{{asset('/assets/img/about.png')}}" alt="">
  </div>
</body>
</html>
