@extends('layouts.main')
@section('content')
<div class="NoExam">
    <div class="page">
        <img src="{{asset('assets/img/CAO.jpg')}}" alt="">
        <h2>No Exam Now</h2>
    </div>
 </div>
@endsection
