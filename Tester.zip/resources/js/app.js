import './bootstrap';
document.getElementById('something').submit();
