<?php $__env->startSection('content'); ?>
<!-- exam Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row row-cols-1 row-cols-md-3 text-center text-primary justify-content-center align-item-center gap-3 mt-5 " style="cursor: pointer;">
            <div class="col shadow p-5 newExam newExam1" onclick="document.getElementById('examForm').submit();">
                <p>إنشاء اختبار جديد</p>
                <i class="fa-regular fa-file" style="font-size: 50px;"></i>
            </div>
            <div class="col shadow p-5 newExam newExam2" onclick="document.getElementById('examEditForm').submit();">
                <p>اختبار موجود مسبقاً</p>
                <i class="fa-solid fa-book-open " style="font-size: 50px;"></i>
            </div>
            <form action="<?php echo e(Route('exams.create')); ?>" method="GET" id="examForm">
            </form>
            <form action="<?php echo e(Route('exams.index')); ?>" method="GET" id="examEditForm">
            </form>
        </div>
    </div>
  </div>
  <!-- exam End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/exam/home.blade.php ENDPATH**/ ?>