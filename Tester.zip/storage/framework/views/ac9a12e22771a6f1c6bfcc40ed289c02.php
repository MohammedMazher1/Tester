<?php $__env->startSection('content'); ?>
<section class="showExam">
    <div id="app"></div>
        <input type="hidden" id="exam_id" value="<?php echo e($exam->id); ?>">
        <input type="hidden" id="timer" value="<?php echo e($timer); ?>">
    <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <!-- exam Start -->
     <div class="container-fluid pt-5">
        <div class="container questions">
            <div class="question p-3  mb-4" dir="ltr">
                <h4 class="text-primary d-inline-block"><?php echo e($question->question); ?></h4>
                <i class="fa-solid fa-question text-primary"></i>
                <ul class="options-list list-unstyled">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <input type="radio" id="q1-firstOption" name="q<?php echo e($question->id); ?>-Option" style="accent-color:#dc3545">
                        <label for="q1-firstOption" class="questionOptin" value="<?php echo e($option->id); ?>"><h6><?php echo e($option->option); ?></h6></label>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
      </div>
      <!-- exam End -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button id="saveTest" class="border-0 bg-primary px-4 py-2 text-white mx-auto d-block rounded">ارسال</button>
    <script>
        window.onload = function(){
            startTimer();
            }
    </script>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/exam/show.blade.php ENDPATH**/ ?>