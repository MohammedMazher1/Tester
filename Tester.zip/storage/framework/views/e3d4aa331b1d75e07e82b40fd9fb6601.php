<?php $__env->startSection('content'); ?>
<div>
    <div class="row">

        <div class="col-lg-12 small" style="text-align: start">
            <div class="card" style="margin-top: 5%">
                <div class="card-header">
                    <i class="fa fa-align-justify"></i>  اختباراتي
                </div>
                <div class="card-block">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>اسم الاختبار</th>
                                <th>تاريخ الإنشاء</th>
                                <th>تاريخ التعديل</th>
                                <th>عدد الاسئلة</th>
                                <th>الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($exam['name']); ?></td>
                                <td><?php echo e($exam['created_at']); ?></td>
                                <td><?php echo e($exam['updated_at']); ?></td>
                                <td><?php echo e($exam->questions->count()); ?></td>
                                <td>
                                    <form style="display: inline" style="padding-right: 10px;color: red;" action="<?php echo e(Route('exams.edit',$exam['id'])); ?>" method="GET"><button class="dashbordButton border-0" style="outline:none;color:blue;font-size: 18px;
                                        background: transparent;"><i class="fa-regular fa-pen-to-square"></i></button></form>
                                    <span> | </span>
                                    <form style="display: inline" style="padding-left: 10px; color: rgb(23, 159, 238);" action="<?php echo e(Route('exams.destroy',$exam['id'])); ?>" method="POST"><?php echo method_field('DELETE'); ?><?php echo csrf_field(); ?><button class="dashbordButton border-0" style="outline:none;color: red; font-size: 18px;
                                        background: transparent;"><i class="fa-solid fa-trash-can"></i></button></form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div >
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/exam/index.blade.php ENDPATH**/ ?>