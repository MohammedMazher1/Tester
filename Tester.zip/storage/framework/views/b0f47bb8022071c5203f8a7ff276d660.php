<?php $__env->startSection('content'); ?>

<div class="col-sm-10">
    <form method="POST"  action="<?php echo e(route('users.update', $user['id'])); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
    <div class="card" style="margin-right: 25%;margin-top: 10%;">
        <div class="card-header">
            <strong>تعديل بيانات المستخدم </strong>
        </div>
        <div class="card-block">
            <?php if(Session::get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="company">اسم المستخدم</label>
                <input type="text" required class="form-control" name="name" id="name" value="<?php echo e($user['name']); ?>" placeholder="اسم المستخدم">
            </div>

            <div class="form-group">
                <label for="vat">الرقم الجوال</label>
                <input type="tel" required class="form-control" value="<?php echo e($user['phone']); ?>"  name="phone" id="vat" placeholder="776533887">
            </div>

            <div class="row" style="margin: 0">

                <div class="form-group col-sm-8" style="padding: 0">
                    <label for="city">الايميل</label>
                    <input type="email" class="form-control" value="<?php echo e($user['email']); ?>" required name="email" id="city" placeholder="example@outlook.sa">
                </div>

                <div class="form-group col-sm-4" style="padding-left:0">
                    <label for="gender">الجنس</label>
                    <select name="gender" class="form-control">
                        <?php if($user['gender'] == 'Male'): ?>
                            <option selected>Male</option>
                            <option>Female</option>
                        <?php else: ?>
                            <option>Male</option>
                            <option selected>Female</option>
                        <?php endif; ?>
                    </select>
                    <div class="select-dropdown"></div>
                </div>

            </div>
            <div class="row" style="margin: 0">
                <div class="form-group col-sm-12" style="padding: 0">
                    <label for="type">نوع المستخدم</label>
                    <select name="type" class="form-control">
                        <?php if($user['type'] == 'trainer'): ?>
                            <option selected>trainer</option>
                            <option>trainee</option>
                        <?php else: ?>
                            <option>trainer</option>
                            <option selected>trainee</option>
                        <?php endif; ?>
                    </select>
                    <div class="select-dropdown"></div>
                </div>
                <div class="card-footer" style="text-align: left;">
                <button type="submit" class="btn btn-sm btn-primary" style="margin: 0"><i class="fa fa-dot-circle-o"></i> حفظ</button>
                <button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i> الغاء</button>
            </div>
            </div>
            <!--/row-->



        </div>
    </div>
    </form>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/user/edit.blade.php ENDPATH**/ ?>