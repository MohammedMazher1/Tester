    
    <?php $__env->startSection('content'); ?>
    <div class="col-sm-10">
        <form method="POST"  action="<?php echo e(asset('/programs')); ?>">
            <?php echo csrf_field(); ?>
        <div class="card" style="margin-right: 25%;margin-top: 7%;">
            <div class="card-header">
                <strong>اضافة برنامج</strong>

            </div>
            <div class="card-block">
                <?php if(Session::get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('error')); ?>

                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="company">اسم البرنامج</label>
                    <input type="text" required class="form-control" name="name" id="name" placeholder="اسم البرنامج">
                </div>

                <div class="form-group">
                    <label for="vat">وصف البرنامج</label>
                    <textarea required class="form-control" name="description" id="programDescription" cols="30" rows="10"></textarea>
                </div>

                <div class="row" style="margin: 0 ; position: relative;">
                    <div class="form-group col-sm-4" style="padding: 0">
                        <label for="postal-code">المدرب</label>
                        <select name="trainer_id" class="form-control">
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($trainer->id); ?>"><?php echo e($trainer->user['name']); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="select-dropdown"></div>

                    </div>
                <!--/row-->
                <div class="form-group" style="position: absolute;bottom: 0;left: 0;">
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> حفظ</button>
                </div>

                </div>
            </div>
        </div>
        </form>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/program/create.blade.php ENDPATH**/ ?>