<?php $__env->startSection('content'); ?>
    <div class="examlist" onclick="docement">
        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(Route('list',$exam->id)); ?>">
            <div class="">
                <i class="fa-solid fa-question"></i>
                <h4><?php echo e($exam->name); ?></h4>
                <span>question <?php echo e($exam->questions->count()); ?></span>
                <i class="fa-solid fa-star text-primary "></i>
                <i class="fa-solid fa-star text-primary"></i>
                <i class="fa-solid fa-star text-primary"></i>
                <i class="fa-solid fa-star text-primary"></i>
            </div>
        </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/admin/examList.blade.php ENDPATH**/ ?>