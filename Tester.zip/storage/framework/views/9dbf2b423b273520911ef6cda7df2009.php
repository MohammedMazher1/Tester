<?php $__env->startSection('content'); ?>
  <!-- exam Start -->
  <div class="container-fluid py-5">
    <div id="error" class="danger"></div>
    <div class="container questions">
        <form action="" id="examEditForm">
            <div>
                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="exam_id" id="exam_id" value="<?php echo e($exam->id); ?>">
                <input type="text" class="form-control w-50 mx-auto px-5" id="exam_name" required placeholder="اسم الاختبار" value="<?php echo e($exam->name); ?>">
                <div class="row row-cols-1 row-cols-md-3 justify-content-around  gap-3">
                    <div class="form-group  row row-cols-1 gap-3 text-right rounded  text-white  p-2 position-relative mt-4 bg-primary">
                        <span >الاختبار القبلي</span>
                        <input type="date" value="<?php echo e($exam->date_of_preTest); ?>" class="form-control" name="date_of_preTest" id="date_of_preTest" required placeholder="التاريخ">
                        <input type="time" value="<?php echo e($exam->time_of_preTest); ?>" class="form-control" name="time_of_preTest" id="time_of_preTest" required placeholder="الوقت">
                    </div>
                    <div class="form-group row row-cols-1 gap-3 rounded text-white text-right p-2 position-relative mt-4 bg-primary">
                        <span class="text"> الاختبار البعدي</span>
                        <input type="date" value="<?php echo e($exam->date_of_postTest); ?>" class="form-control" name="date_of_postTest" id="date_of_postTest" required placeholder="التاريخ">
                        <input type="time" value="<?php echo e($exam->date_of_postTest); ?>" class="form-control" name="time_of_postTest" id="time_of_postTest" required placeholder="الوقت">
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="question p-3 bg-primary mb-4" dir="ltr">
                <input type="text" class="questionInput form-control mb-2 w-50" required placeholder="اكتب سوالك هنا ..." name="q" value="<?php echo e($question->question); ?>">
                <ul class="options-list list-unstyled">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php if($option->status == 1): ?>
                        <input type="radio" name="q<?php echo e($question->id); ?>-Option" value="HTML" checked>
                        <?php else: ?>
                        <input type="radio" name="q<?php echo e($question->id); ?>-Option" value="HTML" >
                        <?php endif; ?>
                        <label for="q1-firstOption">
                            <input type="text" value="<?php echo e($option->option); ?>" name="q<?php echo e($question->id); ?>-Option" class="form-control optionInput" placeholder="OPTION" required>
                        </label>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>


    </div>
    <div class="container">
    <button id="editExam" class="border-0 bg-primary px-4 py-2 text-white mx-auto d-block rounded">ارسال</button>
    </div>
  </div>
  <!-- exam End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tester\resources\views/exam/edit.blade.php ENDPATH**/ ?>